import {faculty} from './faculty';

describe('Faculty', () => {
  it('should create an instance', () => {
    expect(new faculty()).toBeTruthy();
  });
});
