export class faculty {
    
    facName:string;

    stream:string;

location:string;

   
    
    
}
