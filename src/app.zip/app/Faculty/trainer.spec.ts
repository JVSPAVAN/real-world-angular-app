import {trainer} from './trainer';

describe('trainer', () => {
  it('should create an instance', () => {
    expect(new trainer()).toBeTruthy();
  });
});
