export class trainer {
    Trainer_Id:any;

    Trainer_Name:string;
Trainer_Experience:any;

Stream:string;
contact_number:any;
Address:string;
c:any;
   
    
    
}
