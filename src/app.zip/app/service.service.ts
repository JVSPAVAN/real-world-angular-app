import { Injectable } from '@angular/core';

import { faculty } from '../app/Faculty/faculty';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';

import {delay,catchError} from 'rxjs/operators';

import {trainer} from '../app/Faculty/trainer';
import { throwError } from 'rxjs';
import { Http, RequestOptions, Response, Headers } from "@angular/http";

@Injectable()
export class Service {

    faculty:faculty[];
    

constructor(private http:Http) {
 
 
 this.faculty  = [ {facName:'Priya',stream:'Java',location:'CHN'},
                     {facName:'Mani',stream:'Java',location:'CHN'},
                     {facName:'Febin',stream:'Java',location:'TVM'},
                     {facName:'Manasa',stream:'Java',location:'HYD'},
                     {facName:'Revathy',stream:'.Net',location:'CHN'},
                     {facName:'Krithiga',stream:'.Net',location:'CHN'},
                     {facName:'Nagalakshmi',stream:'CM',location:'CHN'},
                 ];
 

}

private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }


getAllTrainers(): Observable<trainer[]> {
    
    return this.http.get('http://localhost:8080/ComputerTrainingCenter/Controller?action=ViewAll').pipe(map((resp)=>{
     
        return this.handleResponse(resp);
        
        
    }),catchError((error)=>{
        
        
        return throwError(error);
        //return Observable.throw("Server Communication Failed");
    }))

    //return Observable.of(this.customers).pipe(delay(5000));

}


/*deleteTrainer(trainer_id){}*/

deleteTrainer( trainer_id: string ): Observable<trainer> {

   var  url ='http://localhost:8080/ComputerTrainingCenter/Controller?Trainer_Id='+trainer_id+'&action=View';
    return this.http.get(url).pipe(map((resp)=>{
        
        return this.handleResponse(resp);
        
        
    }),catchError((error)=>{
        
        
        return throwError(error);
        //return Observable.throw("Server Communication Failed");
    }))

    
    


}



UpdateTrainer( trainer1: trainer ): Observable<trainer> {
    
   


    var trainerid=trainer1.Trainer_Id;
    console.log("in update trainerid--"+trainerid);
    var trainer_exp=trainer1.Trainer_Experience;
    console.log("in update trainer_exp--"+trainer_exp);
    var stream=trainer1.Stream;
    console.log("in update stream--"+stream);
    var contactNum=trainer1.contact_number;
    console.log("in update contactNum--"+contactNum);
    var address=trainer1.Address;
    console.log("in update address--"+address);
        
        

    
    var  url ='http://localhost:8080/ComputerTrainingCenter/Controller?Trainer_Id='+trainerid+'&Trainer_Experience='+trainer_exp+'&Stream='+stream+'&contact_number='+contactNum+'&Address='+address+'&action=Update';
        console.log("url-->"+url);
        
        var  url1 ='http://localhost:8080/ComputerTrainingCenter/Controller?action=Update';
        console.log("url1-->"+url1);
        
        
     return this.http.post(url1,trainer1).pipe(map((resp)=>{
         
         return this.handleResponse(resp);
         
         
     }),catchError((error)=>{
         
         
         return throwError(error);
         //return Observable.throw("Server Communication Failed");
     }))

     
     


 }



/*trainer(Trainer_Id:any,Trainer_Name: string, Trainer_Experience:any,Stream:string,contact_number:any,Address:string,c:any): Observable<trainer> {
    //let body = JSON.stringify({"Trainer_Id":Trainer_Id,"Trainer_Name": Trainer_Name, "Trainer_Experience":Trainer_Experience,"Stream": Stream,"contact_number":contact_number,"Address":Address,"c":c});
    let body=JSON.parse(trainer);
    let headers = new Headers({'Content-Type': 'application/json'});
    let options = new RequestOptions({headers: headers});
    return this.http.post('http://localhost:8080/ComputerTrainingCenter/Controller?Trainer_Id=1&action=View', body, options);
  }*/



getAllFaculties():faculty[]{
    
    return this.faculty;
    
}

getFacultybyName(facultyname:string):faculty{
    console.log("inside service"+facultyname);
   
    return this.faculty.filter((value)=>{
        console.log("inside service value"+value.facName);
        if(value.facName==facultyname){
        return true;
        }

        return false;

        })[0];
        }


getFacultybyStream(stream:string):faculty[]{
    console.log("inside service"+stream);
   
    return this.faculty.filter((value)=>{
        console.log("inside service value"+value.facName);
        if(value.stream==stream){
        return true;
        }

        return false;

        });
        }

handleResponse(resp:any){
    
    if(resp instanceof Response){
        console.log("resp"+resp);
        if(resp.ok==true){
            
            console.log("resp"+resp);
            console.log("text=="+resp.text());
            
            
           console.log("json-->"+resp.json().trainer);
           
          /* let body = <trainer[]>resp.json();        
           // return array from json file
           
           console.log("body"+body);
           return body || []; */
           
            return resp.json().trainer;
           // return resp;
          }
            return resp;           
    }else{
        return resp;
    }
    
}

}





